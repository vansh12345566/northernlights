"use client"

import { useEffect, useState } from "react"

export default function Component() {
  const [particles, setParticles] = useState<Array<{ id: number; x: number; y: number; size: number; delay: number }>>(
    [],
  )
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 })
  const [isDarkMode, setIsDarkMode] = useState(false) // Start with light mode (dark theme)
  const [mainText, setMainText] = useState("hey this is Vansh.")
  const [displayText, setDisplayText] = useState("hey this is Vansh.")
  const [isTyping, setIsTyping] = useState(false)
  const [isMobile, setIsMobile] = useState(false)

  useEffect(() => {
    // Check if device is mobile
    const checkMobile = () => {
      setIsMobile(window.innerWidth < 768 || "ontouchstart" in window)
    }

    checkMobile()
    window.addEventListener("resize", checkMobile)

    return () => window.removeEventListener("resize", checkMobile)
  }, [])

  useEffect(() => {
    // Reduce particles on mobile for better performance
    const particleCount = isMobile ? 25 : 50
    const newParticles = Array.from({ length: particleCount }, (_, i) => ({
      id: i,
      x: Math.random() * 100,
      y: Math.random() * 100,
      size: Math.random() * (isMobile ? 3 : 4) + 1,
      delay: Math.random() * 4,
    }))
    setParticles(newParticles)
  }, [isMobile])

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      setMousePosition({
        x: (e.clientX / window.innerWidth) * 100,
        y: (e.clientY / window.innerHeight) * 100,
      })
    }

    const handleTouchMove = (e: TouchEvent) => {
      if (e.touches.length > 0) {
        const touch = e.touches[0]
        setMousePosition({
          x: (touch.clientX / window.innerWidth) * 100,
          y: (touch.clientY / window.innerHeight) * 100,
        })
      }
    }

    if (!isMobile) {
      window.addEventListener("mousemove", handleMouseMove)
    } else {
      window.addEventListener("touchmove", handleTouchMove, { passive: true })
      window.addEventListener("touchstart", handleTouchMove, { passive: true })
    }

    return () => {
      window.removeEventListener("mousemove", handleMouseMove)
      window.removeEventListener("touchmove", handleTouchMove)
      window.removeEventListener("touchstart", handleTouchMove)
    }
  }, [isMobile])

  // Typing animation effect for just the name
  useEffect(() => {
    const typeNameChange = async (currentText: string, targetText: string) => {
      // Only apply name-changing logic if both texts contain Vansh/वंश
      const currentHasName = currentText.includes("Vansh") || currentText.includes("वंश")
      const targetHasName = targetText.includes("Vansh") || targetText.includes("वंश")

      if (!currentHasName || !targetHasName) {
        // For non-name texts, just set directly without animation
        setDisplayText(targetText)
        setIsTyping(false)
        return
      }

      setIsTyping(true)

      // Find the position of "Vansh" or "वंश" in the text
      const vanshIndex = currentText.indexOf("Vansh")
      const devanagariIndex = currentText.indexOf("वंश")

      let startIndex, endIndex, oldName, newName

      if (vanshIndex !== -1) {
        startIndex = vanshIndex
        endIndex = vanshIndex + "Vansh".length // Use actual string length
        oldName = "Vansh"
        newName = "वंश"
      } else if (devanagariIndex !== -1) {
        startIndex = devanagariIndex
        endIndex = devanagariIndex + "वंश".length // Use actual string length
        oldName = "वंश"
        newName = "Vansh"
      } else {
        setIsTyping(false)
        return
      }

      const beforeName = currentText.substring(0, startIndex)
      const afterName = currentText.substring(endIndex)

      // Delete the old name character by character
      for (let i = oldName.length; i >= 0; i--) {
        const partialName = oldName.substring(0, i)
        setDisplayText(beforeName + partialName + afterName)
        await new Promise((resolve) => setTimeout(resolve, 80))
      }

      // Type the new name character by character
      for (let i = 0; i <= newName.length; i++) {
        const partialName = newName.substring(0, i)
        setDisplayText(beforeName + partialName + afterName)
        await new Promise((resolve) => setTimeout(resolve, 120))
      }

      setIsTyping(false)
    }

    if (mainText !== displayText && !isTyping) {
      typeNameChange(displayText, mainText)
    }
  }, [mainText, displayText, isTyping])

  // Auto-switch between Vansh and वंश (only for the main greeting)
  useEffect(() => {
    const interval = setInterval(() => {
      // Only auto-switch if we're showing the main greeting
      if (mainText === "hey this is Vansh.") {
        setMainText("hey this is वंश.")
      } else if (mainText === "hey this is वंश.") {
        setMainText("hey this is Vansh.")
      }
      // Don't auto-switch if showing the surprise message
    }, 3000) // Change every 3 seconds

    return () => clearInterval(interval)
  }, [mainText])

  // Sound effect functions
  const playClickSound = () => {
    try {
      const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)()
      const oscillator = audioContext.createOscillator()
      const gainNode = audioContext.createGain()

      oscillator.connect(gainNode)
      gainNode.connect(audioContext.destination)

      oscillator.frequency.setValueAtTime(800, audioContext.currentTime)
      oscillator.frequency.exponentialRampToValueAtTime(400, audioContext.currentTime + 0.1)

      gainNode.gain.setValueAtTime(0.3, audioContext.currentTime)
      gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.1)

      oscillator.start(audioContext.currentTime)
      oscillator.stop(audioContext.currentTime + 0.1)
    } catch (error) {
      // Fallback for browsers that don't support Web Audio API
      console.log("Audio not supported")
    }
  }

  const playErrorSound = () => {
    try {
      const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)()
      const oscillator = audioContext.createOscillator()
      const gainNode = audioContext.createGain()

      oscillator.connect(gainNode)
      gainNode.connect(audioContext.destination)

      oscillator.frequency.setValueAtTime(300, audioContext.currentTime)
      oscillator.frequency.setValueAtTime(200, audioContext.currentTime + 0.1)
      oscillator.frequency.setValueAtTime(150, audioContext.currentTime + 0.2)

      gainNode.gain.setValueAtTime(0.4, audioContext.currentTime)
      gainNode.gain.setValueAtTime(0.4, audioContext.currentTime + 0.1)
      gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.3)

      oscillator.start(audioContext.currentTime)
      oscillator.stop(audioContext.currentTime + 0.3)
    } catch (error) {
      console.log("Audio not supported")
    }
  }

  const playHoverSound = () => {
    try {
      const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)()
      const oscillator = audioContext.createOscillator()
      const gainNode = audioContext.createGain()

      oscillator.connect(gainNode)
      gainNode.connect(audioContext.destination)

      oscillator.frequency.setValueAtTime(600, audioContext.currentTime)
      oscillator.frequency.exponentialRampToValueAtTime(800, audioContext.currentTime + 0.05)

      gainNode.gain.setValueAtTime(0.1, audioContext.currentTime)
      gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.05)

      oscillator.start(audioContext.currentTime)
      oscillator.stop(audioContext.currentTime + 0.05)
    } catch (error) {
      console.log("Audio not supported")
    }
  }

  const toggleTheme = () => {
    if (!isDarkMode) {
      // When switching from light to northern lights mode
      setMainText("hey this is Vansh.")
      setDisplayText("hey this is Vansh.")
      playClickSound() // Play normal click sound
    } else {
      // When switching from northern lights to light mode
      setMainText("hey this is Vansh.")
      setDisplayText("hey this is Vansh.")
      playClickSound() // Play normal click sound
    }
    setIsDarkMode(!isDarkMode)
  }

  return (
    <div
      className={`min-h-screen flex items-center justify-center relative overflow-hidden transition-colors duration-500 px-4 sm:px-6 lg:px-8 ${
        isDarkMode ? "bg-gradient-to-b from-green-950 via-emerald-950 to-black" : "bg-black"
      } ${isMobile ? "" : "cursor-none"}`}
    >
      {/* Northern Lights Aurora Background - Only in northern lights mode */}
      {isDarkMode && (
        <div className="absolute inset-0 overflow-hidden">
          {/* Aurora Layer 1 - Primary Green */}
          <div className="absolute inset-0 opacity-40">
            <div
              className="absolute w-full h-96 bg-gradient-to-r from-transparent via-green-400/40 to-transparent blur-3xl animate-aurora-1"
              style={{
                top: "10%",
                transform: "rotate(-15deg) scale(1.5)",
                transformOrigin: "center",
              }}
            ></div>
            <div
              className="absolute w-full h-64 bg-gradient-to-r from-transparent via-emerald-400/35 to-transparent blur-2xl animate-aurora-2"
              style={{
                top: "20%",
                transform: "rotate(10deg) scale(1.3)",
                transformOrigin: "center",
              }}
            ></div>
          </div>

          {/* Aurora Layer 2 - Secondary Green Tones */}
          <div className="absolute inset-0 opacity-35">
            <div
              className="absolute w-full h-80 bg-gradient-to-r from-transparent via-green-300/30 to-transparent blur-3xl animate-aurora-3"
              style={{
                top: "15%",
                transform: "rotate(5deg) scale(1.4)",
                transformOrigin: "center",
              }}
            ></div>
            <div
              className="absolute w-full h-72 bg-gradient-to-r from-transparent via-lime-400/25 to-transparent blur-2xl animate-aurora-2"
              style={{
                top: "20%",
                transform: "rotate(-8deg) scale(1.2)",
                transformOrigin: "center",
              }}
            ></div>
          </div>

          {/* Aurora Layer 3 - Subtle Green Variations */}
          <div className="absolute inset-0 opacity-25">
            <div
              className="absolute w-full h-88 bg-gradient-to-r from-transparent via-emerald-300/25 to-transparent blur-3xl animate-aurora-5"
              style={{
                top: "30%",
                transform: "rotate(12deg) scale(1.6)",
                transformOrigin: "center",
              }}
            ></div>
            <div
              className="absolute w-full h-60 bg-gradient-to-r from-transparent via-green-500/20 to-transparent blur-2xl animate-aurora-6"
              style={{
                top: "35%",
                transform: "rotate(-20deg) scale(1.1)",
                transformOrigin: "center",
              }}
            ></div>
          </div>

          {/* Shimmering particles */}
          <div className="absolute inset-0 opacity-30">
            {Array.from({ length: isMobile ? 20 : 40 }, (_, i) => (
              <div
                key={i}
                className="absolute w-1 h-1 bg-green-200 rounded-full animate-shimmer"
                style={{
                  left: `${Math.random() * 100}%`,
                  top: `${Math.random() * 60}%`,
                  animationDelay: `${Math.random() * 5}s`,
                  animationDuration: `${3 + Math.random() * 4}s`,
                }}
              ></div>
            ))}
          </div>
        </div>
      )}

      {/* Enhanced Horizontal Floating Theme Toggle Button - Apple Style - Bottom Center */}
      <div className="fixed bottom-8 left-1/2 transform -translate-x-1/2 z-50">
        <button
          onClick={toggleTheme}
          onMouseEnter={!isMobile ? playHoverSound : undefined}
          onTouchStart={isMobile ? playHoverSound : undefined}
          className={`group relative px-6 py-3 rounded-full transition-all duration-300 hover:scale-105 active:scale-95 cursor-pointer font-medium touch-manipulation backdrop-blur-xl border shadow-2xl animate-float-slow ${
            !isDarkMode
              ? "bg-white/90 hover:bg-white text-gray-900 border-white/20 shadow-white/10"
              : "bg-black/90 hover:bg-black text-white border-black/20 shadow-black/10"
          }`}
          aria-label="Toggle theme"
          style={{
            minWidth: "200px",
            height: "50px",
          }}
        >
          {/* Subtle background glow */}
          <div
            className={`absolute inset-0 rounded-full blur-xl transition-all duration-300 group-hover:blur-2xl ${
              !isDarkMode ? "bg-white/20 group-hover:bg-white/30" : "bg-black/20 group-hover:bg-black/30"
            }`}
          ></div>

          {/* Button content - Horizontal Layout */}
          <div className="relative flex items-center justify-center h-full w-full">
            {/* Horizontal Text */}
            <span
              className="text-sm font-semibold leading-none tracking-wide whitespace-nowrap"
              style={{
                fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',
              }}
            >
              {!isDarkMode ? "Switch to Northern Lights" : "Back to Dark"}
            </span>
          </div>

          {/* Minimal floating indicators */}
          <div className="absolute -inset-2 pointer-events-none">
            <div
              className={`absolute top-2 right-2 w-0.5 h-0.5 rounded-full animate-pulse ${
                !isDarkMode ? "bg-gray-400" : "bg-gray-400"
              }`}
              style={{ animationDelay: "0s", animationDuration: "2s" }}
            ></div>
            <div
              className={`absolute bottom-2 left-2 w-0.5 h-0.5 rounded-full animate-pulse ${
                !isDarkMode ? "bg-gray-400" : "bg-gray-400"
              }`}
              style={{ animationDelay: "1s", animationDuration: "2s" }}
            ></div>
          </div>
        </button>
      </div>

      {/* Custom Cursor - Only on desktop */}
      {!isMobile && (
        <div
          className={`fixed w-4 h-4 rounded-full pointer-events-none z-50 transition-all duration-100 ease-out ${
            isDarkMode ? "bg-white/30" : "bg-white/30"
          }`}
          style={{
            left: `${mousePosition.x}%`,
            top: `${mousePosition.y}%`,
            transform: "translate(-50%, -50%)",
          }}
        ></div>
      )}

      {/* Animated Background Grid - Only show in northern lights mode */}
      {isDarkMode && (
        <div className="absolute inset-0 opacity-10">
          <div
            className={`absolute inset-0 animate-pulse ${
              isDarkMode
                ? "bg-gradient-to-br from-white/5 via-transparent to-white/5"
                : "bg-gradient-to-br from-black/5 via-transparent to-black/5"
            }`}
          ></div>
          <div
            className="absolute inset-0 opacity-20 transition-transform duration-300 ease-out"
            style={{
              backgroundImage: isDarkMode
                ? `linear-gradient(rgba(255,255,255,0.1) 1px, transparent 1px),
                   linear-gradient(90deg, rgba(255,255,255,0.1) 1px, transparent 1px)`
                : `linear-gradient(rgba(0,0,0,0.1) 1px, transparent 1px),
                   linear-gradient(90deg, rgba(0,0,0,0.1) 1px, transparent 1px)`,
              backgroundSize: isMobile ? "30px 30px" : "50px 50px",
              animation: "gridMove 20s linear infinite",
              transform: isMobile
                ? `translate(${(mousePosition.x - 50) * 0.1}px, ${(mousePosition.y - 50) * 0.1}px)`
                : `translate(${(mousePosition.x - 50) * 0.2}px, ${(mousePosition.y - 50) * 0.2}px)`,
            }}
          ></div>
        </div>
      )}

      {/* Floating Particles - Only show in northern lights mode */}
      {isDarkMode &&
        particles.map((particle) => {
          const offsetX = (mousePosition.x - 50) * (isMobile ? 0.2 : 0.4) * ((particle.id % 3) + 1)
          const offsetY = (mousePosition.y - 50) * (isMobile ? 0.2 : 0.4) * ((particle.id % 3) + 1)

          return (
            <div
              key={particle.id}
              className={`absolute rounded-full opacity-20 animate-float transition-transform duration-500 ease-out ${
                isDarkMode ? "bg-white" : "bg-black"
              }`}
              style={{
                left: `${particle.x}%`,
                top: `${particle.y}%`,
                width: `${particle.size}px`,
                height: `${particle.size}px`,
                animationDelay: `${particle.delay}s`,
                animationDuration: `${3 + Math.random() * 4}s`,
                transform: `translate(${offsetX}px, ${offsetY}px)`,
              }}
            ></div>
          )
        })}

      {/* Animated Circles - Only show in northern lights mode */}
      {isDarkMode && (
        <div className="absolute inset-0 pointer-events-none">
          <div
            className={`absolute top-1/4 left-1/4 w-16 h-16 sm:w-32 sm:h-32 border rounded-full animate-spin-slow transition-transform duration-700 ease-out ${
              isDarkMode ? "border-white/10" : "border-black/10"
            }`}
            style={{
              transform: isMobile
                ? `translate(${(mousePosition.x - 50) * 0.15}px, ${(mousePosition.y - 50) * 0.15}px) rotate(${mousePosition.x * 1}deg)`
                : `translate(${(mousePosition.x - 50) * 0.3}px, ${(mousePosition.y - 50) * 0.3}px) rotate(${mousePosition.x * 2}deg)`,
            }}
          ></div>
          <div
            className={`absolute bottom-1/4 right-1/4 w-24 h-24 sm:w-48 sm:h-48 border rounded-full animate-spin-reverse transition-transform duration-500 ease-out ${
              isDarkMode ? "border-white/5" : "border-black/5"
            }`}
            style={{
              transform: isMobile
                ? `translate(${(mousePosition.x - 50) * 0.125}px, ${(mousePosition.y - 50) * 0.125}px) rotate(${mousePosition.x * 0.75}deg)`
                : `translate(${(mousePosition.x - 50) * 0.25}px, ${(mousePosition.y - 50) * 0.25}px) rotate(${mousePosition.x * 1.5}deg)`,
            }}
          ></div>
          <div
            className={`absolute top-1/2 right-1/3 w-12 h-12 sm:w-24 sm:h-24 border rounded-full animate-pulse transition-transform duration-400 ease-out ${
              isDarkMode ? "border-white/15" : "border-black/15"
            }`}
            style={{
              transform: isMobile
                ? `translate(${(mousePosition.x - 50) * 0.175}px, ${(mousePosition.y - 50) * 0.175}px)`
                : `translate(${(mousePosition.x - 50) * 0.35}px, ${(mousePosition.y - 50) * 0.35}px)`,
            }}
          ></div>
        </div>
      )}

      {/* Gradient Orbs - Only show in northern lights mode */}
      {isDarkMode && (
        <>
          <div
            className={`absolute top-10 left-10 w-20 h-20 sm:w-40 sm:h-40 rounded-full blur-xl animate-float-slow transition-transform duration-1000 ease-out ${
              isDarkMode
                ? "bg-gradient-to-r from-white/5 to-transparent"
                : "bg-gradient-to-r from-black/5 to-transparent"
            }`}
            style={{
              transform: isMobile
                ? `translate(${(mousePosition.x - 50) * 0.25}px, ${(mousePosition.y - 50) * 0.25}px)`
                : `translate(${(mousePosition.x - 50) * 0.5}px, ${(mousePosition.y - 50) * 0.5}px)`,
            }}
          ></div>
          <div
            className={`absolute bottom-20 right-20 w-30 h-30 sm:w-60 sm:h-60 rounded-full blur-2xl animate-float-reverse transition-transform duration-800 ease-out ${
              isDarkMode
                ? "bg-gradient-to-l from-white/3 to-transparent"
                : "bg-gradient-to-l from-black/3 to-transparent"
            }`}
            style={{
              transform: isMobile
                ? `translate(${(mousePosition.x - 50) * 0.2}px, ${(mousePosition.y - 50) * 0.2}px)`
                : `translate(${(mousePosition.x - 50) * 0.4}px, ${(mousePosition.y - 50) * 0.4}px)`,
            }}
          ></div>
        </>
      )}

      {/* Interactive Light Effect - Only show in northern lights mode */}
      {isDarkMode && (
        <div
          className={`absolute w-48 h-48 sm:w-96 sm:h-96 bg-gradient-radial rounded-full blur-3xl pointer-events-none transition-all duration-300 ease-out ${
            isDarkMode ? "from-white/5 via-white/2 to-transparent" : "from-black/5 via-black/2 to-transparent"
          }`}
          style={{
            left: `${mousePosition.x}%`,
            top: `${mousePosition.y}%`,
            transform: "translate(-50%, -50%)",
          }}
        ></div>
      )}

      {/* Main Text with Typing Cursor */}
      <div
        className="text-center relative z-10 animate-fade-in transition-all duration-500 ease-out px-4 max-w-4xl mx-auto leading-relaxed"
        style={{
          transform: isMobile
            ? `translate(${(mousePosition.x - 50) * 0.05}px, ${(mousePosition.y - 50) * 0.05}px)`
            : `translate(${(mousePosition.x - 50) * 0.1}px, ${(mousePosition.y - 50) * 0.1}px)`,
        }}
      >
        <h1 className={`text-lg sm:text-2xl md:text-3xl lg:text-4xl font-medium ${"text-white drop-shadow-lg"}`}>
          {displayText}
          {isTyping && <span className={`animate-pulse text-white`}>|</span>}
        </h1>

        {/* Tip Message - only show in northern lights mode */}
        {isDarkMode && (
          <p
            className={`text-base sm:text-lg md:text-xl font-light mt-4 transition-all duration-500 ease-out ${"text-green-300/80"}`}
          >
            i made you feel northern lights, now tip me 5rs
          </p>
        )}
      </div>

      <style jsx>{`
        @keyframes gridMove {
          0% { transform: translate(0, 0); }
          100% { transform: translate(${isMobile ? "30px, 30px" : "50px, 50px"}); }
        }
        
        @keyframes float {
          0%, 100% { transform: translateY(0px) rotate(0deg); }
          50% { transform: translateY(${isMobile ? "-10px" : "-20px"}) rotate(180deg); }
        }
        
        @keyframes float-slow {
          0%, 100% { transform: translate(0, 0) scale(1); }
          50% { transform: translate(${isMobile ? "-5px, -5px" : "-10px, -10px"}) scale(${isMobile ? "1.05" : "1.1"}); }
        }
        
        @keyframes float-reverse {
          0%, 100% { transform: translate(0, 0) scale(1); }
          50% { transform: translate(${isMobile ? "5px, 5px" : "10px, 10px"}) scale(${isMobile ? "0.95" : "0.9"}); }
        }
        
        @keyframes spin-slow {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }
        
        @keyframes spin-reverse {
          from { transform: rotate(360deg); }
          to { transform: rotate(0deg); }
        }
        
        @keyframes fade-in {
          from { opacity: 0; transform: translateY(20px); }
          to { opacity: 1; transform: translateY(0); }
        }

        @keyframes blink {
          0%, 50% { opacity: 1; }
          51%, 100% { opacity: 0.3; }
        }

        @keyframes aurora-1 {
          0%, 100% { transform: translateX(-100%) rotate(-15deg) scale(1.5); opacity: 0.3; }
          50% { transform: translateX(100%) rotate(-15deg) scale(1.5); opacity: 0.6; }
        }

        @keyframes aurora-2 {
          0%, 100% { transform: translateX(100%) rotate(10deg) scale(1.3); opacity: 0.2; }
          50% { transform: translateX(-100%) rotate(10deg) scale(1.3); opacity: 0.5; }
        }

        @keyframes aurora-3 {
          0%, 100% { transform: translateX(-80%) rotate(5deg) scale(1.4); opacity: 0.25; }
          50% { transform: translateX(80%) rotate(5deg) scale(1.4); opacity: 0.5; }
        }

        @keyframes aurora-4 {
          0%, 100% { transform: translateX(120%) rotate(-8deg) scale(1.2); opacity: 0.2; }
          50% { transform: translateX(-120%) rotate(-8deg) scale(1.2); opacity: 0.4; }
        }

        @keyframes aurora-5 {
          0%, 100% { transform: translateX(-150%) rotate(12deg) scale(1.6); opacity: 0.15; }
          50% { transform: translateX(150%) rotate(12deg) scale(1.6); opacity: 0.3; }
        }

        @keyframes aurora-6 {
          0%, 100% { transform: translateX(90%) rotate(-20deg) scale(1.1); opacity: 0.1; }
          50% { transform: translateX(-90%) rotate(-20deg) scale(1.1); opacity: 0.25; }
        }

        @keyframes shimmer {
          0%, 100% { opacity: 0.2; transform: scale(0.8); }
          50% { opacity: 1; transform: scale(1.2); }
        }
        
        .animate-float {
          animation: float ${isMobile ? "4s" : "6s"} ease-in-out infinite;
        }
        
        .animate-float-slow {
          animation: float-slow ${isMobile ? "6s" : "8s"} ease-in-out infinite;
        }
        
        .animate-float-reverse {
          animation: float-reverse ${isMobile ? "8s" : "10s"} ease-in-out infinite;
        }
        
        .animate-spin-slow {
          animation: spin-slow ${isMobile ? "15s" : "20s"} linear infinite;
        }
        
        .animate-spin-reverse {
          animation: spin-reverse ${isMobile ? "12s" : "15s"} linear infinite;
        }
        
        .animate-fade-in {
          animation: fade-in 2s ease-out;
        }

        .animate-blink {
          animation: blink 1s ease-in-out infinite;
        }

        .animate-aurora-1 {
          animation: aurora-1 12s ease-in-out infinite;
        }

        .animate-aurora-2 {
          animation: aurora-2 15s ease-in-out infinite;
        }

        .animate-aurora-3 {
          animation: aurora-3 18s ease-in-out infinite;
        }

        .animate-aurora-4 {
          animation: aurora-4 14s ease-in-out infinite;
        }

        .animate-aurora-5 {
          animation: aurora-5 20s ease-in-out infinite;
        }

        .animate-aurora-6 {
          animation: aurora-6 16s ease-in-out infinite;
        }

        .animate-shimmer {
          animation: shimmer ease-in-out infinite;
        }

        .bg-gradient-radial {
          background: radial-gradient(circle, var(--tw-gradient-stops));
        }

        /* Improve touch targets on mobile */
        @media (max-width: 768px) {
          button {
            min-height: 44px;
            min-width: 44px;
          }
        }
      `}</style>
    </div>
  )
}
